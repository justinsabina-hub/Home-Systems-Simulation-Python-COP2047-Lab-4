from room import Room

class AC:
    @staticmethod
    def increase_temperature(room: Room, amount: float)->None:
        room.set_temperature(room.get_temperature() + amount)

    @staticmethod
    def decrease_temperature(room: Room, amount: float)->None:
        room.set_temperature(room.get_temperature() - amount)