from house import House
from room import Room
from ac import AC

class Controller:
    @staticmethod
    def info_header()-> None:
        print("============================")
        print("Lab 4 - Python")
        print("============================")
        print("Name: Justin Sabina")
        print("Panther ID: 6613643")
        print()

    @staticmethod
    def main()->None:
        print("COP2047 Lab 4")
        Controller.info_header()

        kitchen = Room("Kitchen","White",10.5,12.0,77.0)
        living_room = Room("Living Room","Blue", 16.0,16.0,76.0)
        bedroom = Room("Bedroom","White", 12.0,16.0,76.0)
        bathroom = Room("Bathroom","Green",8.0,6.0,78.0)

        house = House(kitchen,bedroom,bathroom,living_room)
        house.display_info()

        AC.decrease_temperature(kitchen,10)
        AC.increase_temperature(bedroom,12)
        house.display_info()

        house.get_bathroom().set_color("White")
        house.display_info()





if __name__ == "__main__":
    Controller.main()


