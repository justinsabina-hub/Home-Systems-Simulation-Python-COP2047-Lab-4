from room import Room
class House:
    def __init__(self, kitchen: Room, bedroom: Room, bathroom: Room, living_room: Room):
        self.kitchen = kitchen
        self.bedroom = bedroom
        self.bathroom = bathroom
        self.living_room = living_room
    def get_kitchen(self):
        return self.kitchen
    def get_bedroom(self):
        return self.bedroom
    def get_bathroom(self):
        return self.bathroom
    def get_living_room(self):
        return self.living_room
    def area_of_house(self)-> float:
        return self.kitchen.area() + self.bedroom.area() + self.living_room.area() + self.bathroom.area()
    def display_info(self)->None:
        print("============================")
        print("House Information")
        print("============================")
        print(f"Total House Area: {self.area_of_house():.2f}")
        self.display_room("Kitchen",self.kitchen)
        self.display_room("Living Room",self.living_room)
        self.display_room("Bedroom",self.bedroom)
        self.display_room("Bathroom",self.bathroom)

    @staticmethod
    def display_room(lable: str, room: Room)->None:
        print(f"\t{lable} Color: {room.get_color()}\t Area: {room.area():.2f}\t Temp: {room.get_temperature():.1f}")
