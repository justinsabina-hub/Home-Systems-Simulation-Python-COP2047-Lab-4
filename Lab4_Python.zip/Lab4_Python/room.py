class Room:
    def __init__(self, room_type: str, color: str, width: float, length: float, temperature: float )-> None:
        self.room_type = room_type
        self.color = color
        self.width = width
        self.length = length
        self.temperature = temperature
    def get_room_type(self) -> str:
        return self.room_type
    def get_color(self) -> str:
        return self.color
    def set_color(self, new_color: str)-> None:
        self.color = new_color
    def get_width(self) -> float:
        return self.width
    def get_length(self) -> float:
        return self.length
    def get_temperature(self) -> float:
        return self.temperature
    def set_temperature(self, temperature: float)-> None:
        self.temperature = temperature
    def area(self) -> float:
        return self.width * self.length

    def room_display_info(self) -> None:
        print("============================")
        print("Room Information")
        print("============================")
        print("Type: " + self.room_type)
        print("Color: " + self.color)
        print(f"Width: {self.width:.2f}")
        print(f"Length: {self.length:.2f}")
        print()

